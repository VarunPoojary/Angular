export interface User {
    Id: number;            // Assuming the SQL Server table has an Id field
    Name: string;          // Adjust based on your actual table structure
    Age: number;
    Salary: number;
  }
  