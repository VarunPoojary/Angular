import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { User } from '../../models/user.model';

@Component({
  selector: 'app-user-management',  // This is the selector you'll use
  templateUrl: './user-management.component.html',  // This points to the HTML file
  styleUrls: ['./user-management.component.css']
})

export class UserManagementComponent implements OnInit {

  users: User[] = [];
  newUser: User = { Id: 0, Name: '', Age: 0, Salary: 0};
  editMode: boolean = false;
  selectedUser: User | null = null;

  constructor(private userService: UserService) { }

  ngOnInit(): void {
    this.loadUsers();
  }

  // Load users from the API
  loadUsers() {
    this.userService.getUsers().subscribe(data => {
      this.users = data;
    });
  }

  // Add a new user
  addUser() {
    this.userService.addUser(this.newUser).subscribe(() => {
      this.loadUsers();  // Reload users after adding
      this.newUser = { Id: 0, Name: '', Age: 0, Salary:0};  // Reset form
    });
  }

  // Set selected user for updating
  selectUser(user: User) {
    this.selectedUser = { ...user };
    this.editMode = true;
  }

  // Update the user
  updateUser(user: User) {
    if (this.selectedUser) {
      this.userService.updateUser(this.selectedUser).subscribe(() => {
        this.loadUsers();  // Reload users after updating
        this.editMode = false;
        this.selectedUser = null;
      });
    }
  }

  // Delete a user
  deleteUser(userId: number) {
    this.userService.deleteUser(userId).subscribe(() => {
      this.loadUsers();  // Reload users after deleting
    });
  }
}
