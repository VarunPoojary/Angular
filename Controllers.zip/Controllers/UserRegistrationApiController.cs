﻿using Employee.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.UI.WebControls;

namespace Employee.Controllers
{
    public class UserRegistrationApiController : ApiController
    {

        UsersEntities db = new UsersEntities();

        [System.Web.Http.HttpGet]
        public IQueryable<User> ListUsers()
        {

            //List<User> userList = db.Users.ToList();
            return db.Users;
        }

     





        [System.Web.Http.HttpPost]
        public IHttpActionResult AddUser(User newUser)
        {
            db.Users.Add(newUser);
            db.SaveChanges();
            return Ok();
        }

        [System.Web.Http.HttpPut]
        public IHttpActionResult UpdateUser(User updateUser)
        {

            db.Entry(updateUser).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();



            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Entry(updateUser).State = System.Data.Entity.EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                return NotFound();
            }
            return Ok();
        }


        [System.Web.Http.HttpDelete]
        public IHttpActionResult DeleteUser(int id)
        {
            var deleteMenu = db.Users.Where(model => model.Id == id).FirstOrDefault();
            db.Entry(deleteMenu).State = System.Data.Entity.EntityState.Deleted;
            db.SaveChanges();
            return Ok();
        }
    }
}
